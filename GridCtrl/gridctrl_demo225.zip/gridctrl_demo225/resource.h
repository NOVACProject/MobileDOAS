//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by GridCtrlDemo.rc
//
#define IDCANCEL2                       3
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_GRIDCTRLDEMO_DIALOG         102
#define IDR_MAINFRAME                   128
#define IDR_MENU                        128
#define IDB_RESIZE                      129
#define IDC_CURSOR1                     132
#define ID_HIDE2NDROWCOLUMN             133
#define IDB_IMAGES                      141
#define IDC_PRINT_BUTTON                1000
#define IDC_FONT_BUTTON                 1002
#define IDC_SCROLLBAR1                  1003
#define IDC_GRID                        1004
#define IDC_EDIT_ROWS                   1005
#define IDC_SPIN_ROW                    1006
#define IDC_EDIT_COLS                   1007
#define IDC_SPIN_COL                    1008
#define IDC_EDIT_FIXROWS                1009
#define IDC_SPIN_FIXROW                 1010
#define IDC_EDIT_FIXCOLS                1011
#define IDC_SPIN_FIXCOL                 1012
#define IDC_SIZEBOX                     1021
#define IDC_CELL_URL                    1032
#define IDC_CELL_NORMAL                 1034
#define IDC_CELL_READONLY               1035
#define IDC_CELL_CHECK                  1037
#define IDC_CELL_COMBO                  1038
#define IDC_CELL_NUMERIC                1039
#define IDC_CELL_DATETIME               1040
#define IDC_TRACE                       1041
#define IDC_CLEARTRACE                  1042
#define IDC_CELL_DATETIME2              1043
#define ID_EDIT_SELECTALL               32771
#define ID_OPTIONS_ALLOWCELLSELECTION   32772
#define ID_OPTIONS_SHOWVERTICALLINES    32773
#define ID_OPTIONS_SORTONHEADERCLICK    32774
#define ID_OPTIONS_USECALLBACKFUNCTION  32775
#define IDC_ALLOW_SELECTION             33001
#define IDC_VERT_LINES                  33013
#define IDC_HORZ_LINES                  33014
#define IDC_LISTMODE                    33015
#define IDC_EDITABLE                    33016
#define IDC_ROW_RESIZE                  33017
#define IDC_COL_RESIZE                  33018
#define IDC_HEADERSORT                  33019
#define IDC_READ_ONLY                   33020
#define IDC_ITALICS                     33022
#define IDC_TITLETIPS                   33023
#define IDC_INSERT_ROW                  33024
#define IDC_DELETE_ROW                  33025
#define IDC_SINGLESELMODE               33026
#define IDC_TRACKFOCUS                  33027
#define IDC_FRAMEFOCUS                  33028
#define IDC_EXPAND_TO_FIT               33029
#define IDC_AUTO_SIZE                   33030
#define IDC_FILL                        33031
#define IDC_EXPAND_LAST                 33033
#define IDC_SET_FOCUS                   33036
#define IDC_VIRTUAL_MODE                33039
#define IDC_CALLBACK_FUNCTION           33040
#define IDC_FIXEDCELL_SELECTION         33041
#define IDC_FIXEDCOL_SELECTION          33041
#define IDC_VERTICAL_TEXT               33042
#define IDC_FIXEDROW_SELECTION          33043
#define IDC_SINGLECOLSELMODE            33044
#define IDC_EXPAND_USE_FIXED            33045
#define IDC_EDITING_REJECT_ATTEMPT      33046
#define IDC_EDITING_REJECT_CHANGE       33047

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        134
#define _APS_NEXT_COMMAND_VALUE         33048
#define _APS_NEXT_CONTROL_VALUE         1044
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
